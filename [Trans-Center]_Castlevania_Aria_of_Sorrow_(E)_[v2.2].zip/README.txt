Jogo: Castlevania - Aria of Sorrow
Vers�o: Europ�ia
Console: Gameboy Advance
Ano da tradu��o: 2006 / 2007 / 2008 / 2017
Grupo de tradu��o: Trans-Center
Tradutores: Solid_One e spyblack
MSN: thesolidone@gmail.com

---------------------NOTAS-------------------

A rom s� funcionar� se for aplicada na vers�o EUROP�IA da rom. E a rom tem que ser do tipo "sem intro". Ou seja, se tiver aquelas intros criadas pelos grupos que riparam, a tradu��o n�o funcionar�.

E n�o sei se algu�m chegar� a fazer isso, mas caso algu�m escolha iniciar o jogo escolhendo, ao inv�s do portugu�s, o idioma franc�s ou alem�o, alguns textos e gr�ficos dos outros idiomas podem n�o serem exibidos corretamente.

----------LINHA DE HIST�RIA DO JOGO----------

Terceiro e �ltimo jogo da s�rie castlevania lan�ado pra Gameboy Advance. Para uns � considerado o melhor jogo de castlevania feito para GBA, e um dos melhores da s�rie. � bem parecido com o famoso "Symphony of the Night" de PS1.

Diferente de todos os jogos de castlevania at� ent�o, esse � o primeiro onde os acontecimentos s�o no futuro e n�o no passado como antes. O ano dos acontecimentos desse jogo � 2035. O personagem principal se chama Soma Cruz. � um estudante que est� fazendo interc�mbio, estudando no Jap�o.

Tudo come�a quando no dia do primeiro eclipse solar do s�culo XXI, Soma est� indo at� o templo de sua amiga de inf�ncia Mina Hakuba para ver o eclipse com ela. Ao chegar l�, depara-se com a escadaria antes do tempo, que j� estava acostumado em sub�-la para chegar ao templo.

Por�m, estranhamente ele tem uma sensa��o ruim, como se fosse algo tentando evitar que ele se aproximasse do eclipse. Mesmo com essa sensa��o medonha a ponto de lhe causar um pouco de tontura, continuou indo em frente. Ao chegar ao topo, anormalmente ele perdeu a consci�ncia. E quando acordou, deparou-se dentro do castelo do Dr�cula, junto de Mina e outra pessoa estranha.

L�, ele descobre que possui poderes especiais de absorver as almas dos inimigos que mata. E se v� numa situa��o onde se n�o agir, ele e Mina morrer�o.

Come�a ent�o sua jornada pelo castelo para descobrir a verdade sobre esses seus poderes especiais, e para evitar que Dr�cula suba ao trono do castelo.


----------SOBRE A TRADU��O----------

Comecei a traduzir esse jogo mais ou menos em outubro do ano passado. Visto que n�o h� tradu��o decente desse jogo. � um dos melhores jogos de GBA, e entre os tr�s jogos de Castlevania lan�ados pra Gameboy Advance, esse � considerado o melhor.

A iniciativa primeiramente foi do spyblack nos tempos que ele era da MiB. Foi ele que descobriu os alfabetos do jogo e tamb�m ele quem fez a imagem de splash do CAOS.

Tive que pesquisar v�rios detalhes sobre nomes de espadas usadas em guerras no passado, nomes de alguns �tens (mais destacadamente as "guloseimas"), alguns nomes de inimigos na qual foram inspirados em v�rias mitologias, etc.

A maior parte dos textos foi facilmente encontrada. E sobre os acentos, como usei a rom europ�ia, o alfabeto j� possu�a v�rios acentos e caracteres provindos do idioma franc�s e do alem�o. Como n�o haviam todos, e o spyblack havia achado o alfabeto, eu troquei alguns caracteres acentuados in�teis, como "�", "�", "�", pelos que faltavam. Por isso que, se por acaso algu�m escolher o idioma franc�s ou alem�o, eles estar�o com uns caracteres estranhos, sem falar que talvez parte dos gr�ficos estejam em portugu�s ao inv�s de alem�o ou franc�s.

Posteriormente, praticamente tudo quanto � gr�fico comprimido desse jogo foi modificado. V�rios nomes que realmente mereciam ser modificados, o foram. Tudo isso gra�as ao grande membro da TC chamado Fallen_Soul e seus esfor�os quanto a isso. Sem ele, as vers�es posteriores � 1.0 ainda n�o existiriam.

Em 2008, Hyllian reapareceu na cena de romhacking brasileira e lan�ou uma tradu��o para sua continua��o, Castlevania Dawn of Sorrow, de NDS, onde eu o ajudei um pouco editando gr�ficos mais complexos. Com essa tradu��o, percebeu-se v�rios erros da localiza��o americana do Aria of Sorrow para GBA. Assim sendo, em meados de 2010, fiz uma revis�o textual completa na mesma, de modo a sincronizar os termos das tradu��es (Poder da Domin�ncia), bem como dar uma naturalidade e sentido maior � hist�ria do jogo.

Por fim, com esta vers�o 2.2 da tradu��o, acredito que seja definitiva. Ela deveria ser lan�ada em meados de 2010, em conjunto com uma poss�vel revis�o textual tamb�m na tradu��o do Dawn of Sorrow para sincronizar termos com outras tradu��es de jogos de Castlevania que participei. No entanto, como o corre-corre da cidade �... grande, eu ainda n�o tive tempo de parar pra ver o Dawn of Sorrow. Ent�o, para n�o mais postergar, decidi lan�ar logo esta vers�o s� agora, em 2017.

----------STATUS DA TRADU��O----------

Textos: 100%
(Traduzi tudo que eu pude traduzir.)

Acentos: 100%
(Tudo colocado. Alguns j� tinham. Outros eram in�teis demais e troquei pelos que faltavam.)

Gr�ficos: 100%
(Todos os gr�ficos foram modificados. Alguns estavam descomprimidos, enquanto que a maioria estava comprimida. Nessa vers�o, editei os �ltimos gr�ficos e tilemaps referente aos cr�ditos finais do jogo, terminando o 0,1% que faltava dessa parte gr�fica.)

Ponteiros: 100%
(Usei e abusei de mexer na tabela de ponteiros. Bati um pouco de cabe�a at� descobrir que os ponteiros s� funcionavam se eu voltasse dois espa�os para tr�s a partir da primeira letra da palavra, como referencial.)

-------AGRADECIMENTOS-------

-Spyblack, por ter come�ado esse projeto um tempo atr�s, e pela imagem do splash;
-Fallen_Soul, pelo tedios�ssimo trabalho quanto � descompress�o dos gr�ficos comprimidos;
-kmikz, pela inser��o do splash screen das vers�es antigas;
-todo o pessoal da Trans-center pelo apoio e ajuda na tradu��o.
	
----------HIST�RIA----------

Vers�o 2.2 - 11/11/17
 Quarto lan�amento. Vers�o Europ�ia
 - Sincronizados termos com a tradu��o de Dawn of Sorrow, feita por Hyllian em 2008;
 - Revisados scripts para dar uma naturalidade e sentido maior � hist�ria do jogo;
 - Efetuadas corre��es gr�ficas menores, de modo a evitar abrevia��es.

Vers�o 2.1 - 31/01/08
 Terceiro lan�amento. Vers�o Europ�ia
 - Algumas corre��es ortogr�ficas minuciosas;
 - Algumas corre��ezinhas gr�ficas;
 - Modifica��o dos cr�ditos finais do jogo, o que seria correspondente ao 0,1% restante da parte gr�fica;
 - Remo��o da splash screen.

Vers�o 2.0 - 01/06/07
 Segundo lan�amento. Vers�o Europ�ia
 - V�rias corre��es ortogr�ficas;
 - Edi��o de 99,9% dos gr�ficos comprimidos.

Vers�o 1.0 - 25/12/06
 Primeiro lan�amento. Vers�o Europ�ia
